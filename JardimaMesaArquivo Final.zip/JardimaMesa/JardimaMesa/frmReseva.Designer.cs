﻿
namespace JardimaMesa
{
    partial class frmReseva
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLusty = new System.Windows.Forms.Label();
            this.btnResVoltar = new System.Windows.Forms.Button();
            this.btnCadReserva = new System.Windows.Forms.Button();
            this.imgLogoReserva = new System.Windows.Forms.PictureBox();
            this.txbResExp = new System.Windows.Forms.TextBox();
            this.txbResNPessoas = new System.Windows.Forms.TextBox();
            this.txbResHora = new System.Windows.Forms.TextBox();
            this.txbResFone = new System.Windows.Forms.TextBox();
            this.txbResNome = new System.Windows.Forms.TextBox();
            this.lblResExp = new System.Windows.Forms.Label();
            this.lblResNPessoas = new System.Windows.Forms.Label();
            this.lblResHora = new System.Windows.Forms.Label();
            this.lblResFone = new System.Windows.Forms.Label();
            this.lblResNome = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoReserva)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLusty
            // 
            this.lblLusty.AutoSize = true;
            this.lblLusty.BackColor = System.Drawing.Color.Transparent;
            this.lblLusty.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLusty.Location = new System.Drawing.Point(723, 400);
            this.lblLusty.Name = "lblLusty";
            this.lblLusty.Size = new System.Drawing.Size(59, 9);
            this.lblLusty.TabIndex = 12;
            this.lblLusty.Text = "LUSTYCODE©";
            // 
            // btnResVoltar
            // 
            this.btnResVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResVoltar.Location = new System.Drawing.Point(550, 275);
            this.btnResVoltar.Name = "btnResVoltar";
            this.btnResVoltar.Size = new System.Drawing.Size(120, 50);
            this.btnResVoltar.TabIndex = 15;
            this.btnResVoltar.Text = "VOLTAR";
            this.btnResVoltar.UseVisualStyleBackColor = true;
            this.btnResVoltar.Click += new System.EventHandler(this.btnResVoltar_Click);
            // 
            // btnCadReserva
            // 
            this.btnCadReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadReserva.Location = new System.Drawing.Point(390, 275);
            this.btnCadReserva.Name = "btnCadReserva";
            this.btnCadReserva.Size = new System.Drawing.Size(120, 50);
            this.btnCadReserva.TabIndex = 14;
            this.btnCadReserva.Text = "FAZER RESERVA";
            this.btnCadReserva.UseVisualStyleBackColor = true;
            this.btnCadReserva.Click += new System.EventHandler(this.btnCadReserva_Click);
            // 
            // imgLogoReserva
            // 
            this.imgLogoReserva.Image = global::JardimaMesa.Properties.Resources.logo_escuro1;
            this.imgLogoReserva.Location = new System.Drawing.Point(30, 75);
            this.imgLogoReserva.Name = "imgLogoReserva";
            this.imgLogoReserva.Size = new System.Drawing.Size(250, 250);
            this.imgLogoReserva.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgLogoReserva.TabIndex = 35;
            this.imgLogoReserva.TabStop = false;
            // 
            // txbResExp
            // 
            this.txbResExp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbResExp.Location = new System.Drawing.Point(430, 235);
            this.txbResExp.Name = "txbResExp";
            this.txbResExp.Size = new System.Drawing.Size(300, 21);
            this.txbResExp.TabIndex = 34;
            // 
            // txbResNPessoas
            // 
            this.txbResNPessoas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbResNPessoas.Location = new System.Drawing.Point(430, 195);
            this.txbResNPessoas.Name = "txbResNPessoas";
            this.txbResNPessoas.Size = new System.Drawing.Size(300, 21);
            this.txbResNPessoas.TabIndex = 33;
            // 
            // txbResHora
            // 
            this.txbResHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbResHora.Location = new System.Drawing.Point(430, 155);
            this.txbResHora.Name = "txbResHora";
            this.txbResHora.Size = new System.Drawing.Size(300, 21);
            this.txbResHora.TabIndex = 32;
            // 
            // txbResFone
            // 
            this.txbResFone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbResFone.Location = new System.Drawing.Point(430, 115);
            this.txbResFone.Name = "txbResFone";
            this.txbResFone.Size = new System.Drawing.Size(300, 21);
            this.txbResFone.TabIndex = 31;
            // 
            // txbResNome
            // 
            this.txbResNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbResNome.Location = new System.Drawing.Point(430, 75);
            this.txbResNome.Name = "txbResNome";
            this.txbResNome.Size = new System.Drawing.Size(300, 21);
            this.txbResNome.TabIndex = 30;
            // 
            // lblResExp
            // 
            this.lblResExp.AutoSize = true;
            this.lblResExp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResExp.Location = new System.Drawing.Point(299, 238);
            this.lblResExp.Name = "lblResExp";
            this.lblResExp.Size = new System.Drawing.Size(111, 16);
            this.lblResExp.TabIndex = 29;
            this.lblResExp.Text = "EXPERIÊNCIA:";
            // 
            // lblResNPessoas
            // 
            this.lblResNPessoas.AutoSize = true;
            this.lblResNPessoas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResNPessoas.Location = new System.Drawing.Point(306, 198);
            this.lblResNPessoas.Name = "lblResNPessoas";
            this.lblResNPessoas.Size = new System.Drawing.Size(104, 16);
            this.lblResNPessoas.TabIndex = 28;
            this.lblResNPessoas.Text = "Nº PESSOAS:";
            // 
            // lblResHora
            // 
            this.lblResHora.AutoSize = true;
            this.lblResHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResHora.Location = new System.Drawing.Point(355, 158);
            this.lblResHora.Name = "lblResHora";
            this.lblResHora.Size = new System.Drawing.Size(55, 16);
            this.lblResHora.TabIndex = 27;
            this.lblResHora.Text = "HORA:";
            // 
            // lblResFone
            // 
            this.lblResFone.AutoSize = true;
            this.lblResFone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResFone.Location = new System.Drawing.Point(319, 118);
            this.lblResFone.Name = "lblResFone";
            this.lblResFone.Size = new System.Drawing.Size(91, 16);
            this.lblResFone.TabIndex = 26;
            this.lblResFone.Text = "TELEFONE:";
            // 
            // lblResNome
            // 
            this.lblResNome.AutoSize = true;
            this.lblResNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResNome.Location = new System.Drawing.Point(354, 78);
            this.lblResNome.Name = "lblResNome";
            this.lblResNome.Size = new System.Drawing.Size(56, 16);
            this.lblResNome.TabIndex = 25;
            this.lblResNome.Text = "NOME:";
            // 
            // frmReseva
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(48)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(784, 411);
            this.Controls.Add(this.imgLogoReserva);
            this.Controls.Add(this.txbResExp);
            this.Controls.Add(this.txbResNPessoas);
            this.Controls.Add(this.txbResHora);
            this.Controls.Add(this.txbResFone);
            this.Controls.Add(this.txbResNome);
            this.Controls.Add(this.lblResExp);
            this.Controls.Add(this.lblResNPessoas);
            this.Controls.Add(this.lblResHora);
            this.Controls.Add(this.lblResFone);
            this.Controls.Add(this.lblResNome);
            this.Controls.Add(this.btnResVoltar);
            this.Controls.Add(this.btnCadReserva);
            this.Controls.Add(this.lblLusty);
            this.Name = "frmReseva";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RESERVAS";
            this.Load += new System.EventHandler(this.frmReseva_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoReserva)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblLusty;
        private System.Windows.Forms.Button btnResVoltar;
        private System.Windows.Forms.Button btnCadReserva;
        private System.Windows.Forms.PictureBox imgLogoReserva;
        private System.Windows.Forms.TextBox txbResExp;
        private System.Windows.Forms.TextBox txbResNPessoas;
        private System.Windows.Forms.TextBox txbResHora;
        private System.Windows.Forms.TextBox txbResFone;
        private System.Windows.Forms.TextBox txbResNome;
        private System.Windows.Forms.Label lblResExp;
        private System.Windows.Forms.Label lblResNPessoas;
        private System.Windows.Forms.Label lblResHora;
        private System.Windows.Forms.Label lblResFone;
        private System.Windows.Forms.Label lblResNome;
    }
}