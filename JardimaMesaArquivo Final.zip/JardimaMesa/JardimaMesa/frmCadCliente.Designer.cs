﻿
namespace JardimaMesa
{
    partial class frmCadCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLusty = new System.Windows.Forms.Label();
            this.btnCliVoltar = new System.Windows.Forms.Button();
            this.btnCliCadastrar = new System.Windows.Forms.Button();
            this.txbCpf = new System.Windows.Forms.TextBox();
            this.txbEmail = new System.Windows.Forms.TextBox();
            this.txbFone = new System.Windows.Forms.TextBox();
            this.txbEndereco = new System.Windows.Forms.TextBox();
            this.txbNome = new System.Windows.Forms.TextBox();
            this.lblCliCpf = new System.Windows.Forms.Label();
            this.lblCliEmail = new System.Windows.Forms.Label();
            this.lblCliFone = new System.Windows.Forms.Label();
            this.lblCliEndereco = new System.Windows.Forms.Label();
            this.lblCliNome = new System.Windows.Forms.Label();
            this.imgLogoCadCli = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoCadCli)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLusty
            // 
            this.lblLusty.AutoSize = true;
            this.lblLusty.BackColor = System.Drawing.Color.Transparent;
            this.lblLusty.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLusty.Location = new System.Drawing.Point(723, 400);
            this.lblLusty.Name = "lblLusty";
            this.lblLusty.Size = new System.Drawing.Size(59, 9);
            this.lblLusty.TabIndex = 3;
            this.lblLusty.Text = "LUSTYCODE©";
            // 
            // btnCliVoltar
            // 
            this.btnCliVoltar.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton;
            this.btnCliVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCliVoltar.Location = new System.Drawing.Point(550, 275);
            this.btnCliVoltar.Name = "btnCliVoltar";
            this.btnCliVoltar.Size = new System.Drawing.Size(120, 50);
            this.btnCliVoltar.TabIndex = 13;
            this.btnCliVoltar.Text = "VOLTAR";
            this.btnCliVoltar.UseVisualStyleBackColor = true;
            this.btnCliVoltar.Click += new System.EventHandler(this.btnCliVoltar_Click);
            // 
            // btnCliCadastrar
            // 
            this.btnCliCadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCliCadastrar.Location = new System.Drawing.Point(390, 275);
            this.btnCliCadastrar.Name = "btnCliCadastrar";
            this.btnCliCadastrar.Size = new System.Drawing.Size(120, 50);
            this.btnCliCadastrar.TabIndex = 12;
            this.btnCliCadastrar.Text = "CADASTRAR CLIENTE";
            this.btnCliCadastrar.UseVisualStyleBackColor = true;
            this.btnCliCadastrar.Click += new System.EventHandler(this.btnCliCadastrar_Click);
            // 
            // txbCpf
            // 
            this.txbCpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbCpf.Location = new System.Drawing.Point(430, 235);
            this.txbCpf.Name = "txbCpf";
            this.txbCpf.Size = new System.Drawing.Size(300, 21);
            this.txbCpf.TabIndex = 23;
            // 
            // txbEmail
            // 
            this.txbEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbEmail.Location = new System.Drawing.Point(430, 195);
            this.txbEmail.Name = "txbEmail";
            this.txbEmail.Size = new System.Drawing.Size(300, 21);
            this.txbEmail.TabIndex = 22;
            // 
            // txbFone
            // 
            this.txbFone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbFone.Location = new System.Drawing.Point(430, 155);
            this.txbFone.Name = "txbFone";
            this.txbFone.Size = new System.Drawing.Size(300, 21);
            this.txbFone.TabIndex = 21;
            // 
            // txbEndereco
            // 
            this.txbEndereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbEndereco.Location = new System.Drawing.Point(430, 115);
            this.txbEndereco.Name = "txbEndereco";
            this.txbEndereco.Size = new System.Drawing.Size(300, 21);
            this.txbEndereco.TabIndex = 20;
            // 
            // txbNome
            // 
            this.txbNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNome.Location = new System.Drawing.Point(430, 75);
            this.txbNome.Name = "txbNome";
            this.txbNome.Size = new System.Drawing.Size(300, 21);
            this.txbNome.TabIndex = 19;
            // 
            // lblCliCpf
            // 
            this.lblCliCpf.AutoSize = true;
            this.lblCliCpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliCpf.Location = new System.Drawing.Point(357, 238);
            this.lblCliCpf.Name = "lblCliCpf";
            this.lblCliCpf.Size = new System.Drawing.Size(53, 16);
            this.lblCliCpf.TabIndex = 18;
            this.lblCliCpf.Text = "C.P.F.:";
            // 
            // lblCliEmail
            // 
            this.lblCliEmail.AutoSize = true;
            this.lblCliEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliEmail.Location = new System.Drawing.Point(349, 198);
            this.lblCliEmail.Name = "lblCliEmail";
            this.lblCliEmail.Size = new System.Drawing.Size(61, 16);
            this.lblCliEmail.TabIndex = 17;
            this.lblCliEmail.Text = "E-MAIL:";
            // 
            // lblCliFone
            // 
            this.lblCliFone.AutoSize = true;
            this.lblCliFone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliFone.Location = new System.Drawing.Point(319, 158);
            this.lblCliFone.Name = "lblCliFone";
            this.lblCliFone.Size = new System.Drawing.Size(91, 16);
            this.lblCliFone.TabIndex = 16;
            this.lblCliFone.Text = "TELEFONE:";
            // 
            // lblCliEndereco
            // 
            this.lblCliEndereco.AutoSize = true;
            this.lblCliEndereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliEndereco.Location = new System.Drawing.Point(314, 118);
            this.lblCliEndereco.Name = "lblCliEndereco";
            this.lblCliEndereco.Size = new System.Drawing.Size(96, 16);
            this.lblCliEndereco.TabIndex = 15;
            this.lblCliEndereco.Text = "ENDEREÇO:";
            // 
            // lblCliNome
            // 
            this.lblCliNome.AutoSize = true;
            this.lblCliNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliNome.Location = new System.Drawing.Point(354, 78);
            this.lblCliNome.Name = "lblCliNome";
            this.lblCliNome.Size = new System.Drawing.Size(56, 16);
            this.lblCliNome.TabIndex = 14;
            this.lblCliNome.Text = "NOME:";
            // 
            // imgLogoCadCli
            // 
            this.imgLogoCadCli.Image = global::JardimaMesa.Properties.Resources.logo_escuro1;
            this.imgLogoCadCli.Location = new System.Drawing.Point(30, 75);
            this.imgLogoCadCli.Name = "imgLogoCadCli";
            this.imgLogoCadCli.Size = new System.Drawing.Size(250, 250);
            this.imgLogoCadCli.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgLogoCadCli.TabIndex = 24;
            this.imgLogoCadCli.TabStop = false;
            // 
            // frmCadCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(48)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(784, 411);
            this.Controls.Add(this.imgLogoCadCli);
            this.Controls.Add(this.txbCpf);
            this.Controls.Add(this.txbEmail);
            this.Controls.Add(this.txbFone);
            this.Controls.Add(this.txbEndereco);
            this.Controls.Add(this.txbNome);
            this.Controls.Add(this.lblCliCpf);
            this.Controls.Add(this.lblCliEmail);
            this.Controls.Add(this.lblCliFone);
            this.Controls.Add(this.lblCliEndereco);
            this.Controls.Add(this.lblCliNome);
            this.Controls.Add(this.btnCliVoltar);
            this.Controls.Add(this.btnCliCadastrar);
            this.Controls.Add(this.lblLusty);
            this.Name = "frmCadCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CADASTRAR CLIENTES";
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoCadCli)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLusty;
        private System.Windows.Forms.Button btnCliVoltar;
        private System.Windows.Forms.Button btnCliCadastrar;
        private System.Windows.Forms.TextBox txbCpf;
        private System.Windows.Forms.TextBox txbEmail;
        private System.Windows.Forms.TextBox txbFone;
        private System.Windows.Forms.TextBox txbEndereco;
        private System.Windows.Forms.TextBox txbNome;
        private System.Windows.Forms.Label lblCliCpf;
        private System.Windows.Forms.Label lblCliEmail;
        private System.Windows.Forms.Label lblCliFone;
        private System.Windows.Forms.Label lblCliEndereco;
        private System.Windows.Forms.Label lblCliNome;
        private System.Windows.Forms.PictureBox imgLogoCadCli;
    }
}